<?php
	include "koneksi.php";
	$footer       = $_POST['footer'];
	$id           = $_POST['id'];
	// query SQL untuk insert data
	$query="UPDATE layout_option_footer  SET footer_content='$footer' WHERE footer_title='$id'";
	mysqli_query($connect, $query);
	header("location:../index.php?page=layout-option&act=footer&notif=success");

?>