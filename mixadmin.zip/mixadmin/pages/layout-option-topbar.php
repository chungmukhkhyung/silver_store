<!-- box header -->
<div class="box-header with-border">
  <h3 class="box-title">Top-Bar
  </h3>
</div>
<!-- /.box-header -->
<!-- form start -->
            <form class="form-horizontal" action="pages/layout-option-topbar-save.php" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-1 control-label">Email</label>

                  <div class="col-sm-10">
                    <input type="email" class="form-control" name ="email" id="email" placeholder="name@company.com">
                  </div>
                </div>
               <div class="form-group">
                  <label class="col-sm-1 control-label">Phone</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="phone" id="phone" placeholder="+62 812 3456 7890">
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary"> Save</button>
              </div>
              <!-- /.box-footer -->
            </form>
<!-- form -->