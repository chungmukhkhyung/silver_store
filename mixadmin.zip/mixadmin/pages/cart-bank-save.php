<?php
	include "koneksi.php";
	$target_dir 	= "image";
	$bank_name     = $_POST['bank_name'];
	$acc_name   = $_POST['acc_name'];
	$acc_num   = $_POST['acc_num'];
	$size   	= $_FILES["bank_img"]["size"];
	$bank_img = $_FILES["bank_img"]["name"];
	$uploadOk = 1;
	// memeriksa apakah filenya adalah gambar atau bukan
	if(isset($_POST["submit"])) {
	    $check = getimagesize($_FILES["bank_img"]["tmp_name"]);
	    if($check !== false) {
	        echo "format file gambarnya adalah : " . $check["mime"] . ".";
	        $uploadOk = 1;
	    } else {
	        echo "bukan file gambar";
	        $uploadOk = 0;
	    }
	}
	
	// jika uploadok nilanya 0 maka upload gambar gagal,
	if ($uploadOk == 0) {
		header("location:../index.php?page=cart&act=bank&notif=error");

	//jika tidak maka akan dilakukan proses upload gambar
	} else {
		if($size<=1000000){
			$temp = explode(".", $_FILES["bank_img"]["name"]);//untuk mengambil nama file gambarnya saja tanpa format gambarnya
			$nama_baru = round(microtime(true)) . '.' . end($temp);//fungsi untuk membuat nama acak
		    if (move_uploaded_file($_FILES["bank_img"]["tmp_name"], $target_dir."/" . $nama_baru)) {
		    	mysqli_query($connect, "INSERT INTO `mcart_bank`(`mcart_bank_id`, `mcart_bank_name`, `mcart_bank_acc_number`, `mcart_bank_acc_name`, `mcart_bank_dir`) VALUES ('','$bank_name','$acc_num','acc_name','$target_dir/$nama_baru')");
		    	header("location:../index.php?page=cart&act=bank&notif=success");

		    } else {
		        header("location:../index.php?page=cart&act=bank&notif=error");
		    }
		}
		else{
	        header("location:../index.php?page=cart&act=bank&notif=error");
		}    
	}
?>