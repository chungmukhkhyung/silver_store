<?php 
  include "koneksi.php";
  $category  = mysqli_query($connect, "SELECT * FROM product_category");
?>
<div class="box-header with-border">
  <h3 class="box-title">Add New Post
  </h3>
</div>
<!-- /.box-header -->
<div class="box-body pad">
  <form action="pages/product-add-save.php" method="post" enctype="multipart/form-data">
    <input class="form-control input-lg" type="text" placeholder="Title" name="product_title">
    <br>
    <textarea class="textarea" name="product_description" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
    <br>
    <br>
    <div class="form-group">
      <label for="inputEmail3" class="col-sm-2 control-label">Price (IDR)</label>
      <div class="col-sm-4">
        <input type="number" class="form-control" id="inputEmail3" name="product_price" placeholder="50000">
      </div>

      <label for="inputEmail3" class="col-sm-2 control-label">Total Stock</label>
      <div class="col-sm-4">
        <input type="number" class="form-control" id="inputEmail3" name="product_stock" placeholder="50000">
      </div>
      <br>
      <br>
      <br>
      <label for="inputEmail3" class="col-sm-2 control-label">Category</label>
      <div class="col-sm-4">
      <select name="product_category" class="form-control">
        <?php 
        foreach ($category as $row) {
          echo'<option value="'.$row['product_category_id'].'>'.$row['product_category_name'].'</option>';
          echo'<option value="'.$row['product_category_id'].'>'.$row['product_category_name'].'</option>';
        }
        ?>
      </select>
      </div>
    </div>
   
    <br>
    <br>
    <label for="exampleInputFile">Upload Product Image 1</label>
    <input type="file" id="exampleInputFile" name="product_image1">

    <br>
    <br>
    <label for="exampleInputFile">Upload Product Image 2</label>
    <input type="file" id="exampleInputFile" name="product_image2">

    <br>
    <br>
    <label for="exampleInputFile">Upload Product Image 3</label>
    <input type="file" id="exampleInputFile" name="product_image3">
    <br>
    <div class="box-footer">
      <button type="submit" class="btn btn-primary"> Save</button>
    </div>
  </form>
  <br>
</div>