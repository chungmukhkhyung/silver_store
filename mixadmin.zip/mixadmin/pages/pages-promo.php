<div class="box-header with-border">
  <h3 class="box-title">View Promotion
  </h3>
</div>
<!-- /.box-header -->
<!-- table -->
<div class="box-body pad">
  <table class="table table-hover">
    <tbody><tr>
      <th>Title</th>
      <th>Status</th>
      <th>Date</th>
      <th>Action</th>
    </tr>
    <tr>
      <td>John Doe John Doe</td>
      <td><span class="label label-success">Published</span></td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
    <tr>
      <td>Alexander Pierce</td>
      <td><span class="label label-danger">Draft</span></td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
    <tr>
      <td>sdf fdsa fasdf asd</td>
      <td><span class="label label-danger">Draft</span></td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
    <tr>
      <td>Mike Doe</td>
      <td><span class="label label-success">Published</span></td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
  </tbody>
  </table>
  </div>
  </div>
  <!-- closed table -->

<div class="box box-info">
<div class="box-header with-border">
  <h3 class="box-title">Promotion Information
  </h3>
</div>
<!-- /.box-header -->
<div class="box-body pad">
  <form>
    <input class="form-control input-lg" type="text" placeholder="Title">
    <br>
    <textarea class="textarea" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
    <br>
    <br>
    <label for="exampleInputFile">Upload Image</label>
    <input type="file" id="exampleInputFile">
  </form>
  <br>
  	<a class="btn btn-app" style="margin-top:10px;">
		<i class="fa fa-pencil-square-o"></i> Post
	</a>
</div>

</div>