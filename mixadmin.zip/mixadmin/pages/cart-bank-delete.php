<?php
include 'koneksi.php';
// menyimpan data id kedalam variabel
$mcart_bank_id  = $_GET['mcart_bank_id'];

//delete file
$query=mysqli_query($connect, "SELECT mcart_bank_dir FROM mcart_bank where mcart_bank_id='$mcart_bank_id'");
$dir=mysqli_fetch_array($query);
unlink(__DIR__.'/'.$dir['mcart_bank_dir']); //delete file now

$query="DELETE from mcart_bank where mcart_bank_id='$mcart_bank_id'";
mysqli_query($connect, $query);
// mengalihkan ke halaman index.php
header("location:index.php?page=cart&act=bank&notif=success");

?>