<?php include 'koneksi.php';
$blog  = mysqli_query($connect, "SELECT * FROM pages_contact_us WHERE contact_us_id=1");
$row        = mysqli_fetch_array($blog);
?>

<!-- box header -->
	<div class="box-header">
	  <h3 class="box-title">Contact Info
	  </h3>
	</div>

	<!-- /.box-header -->
	<div class="box-body pad">
	  <form action="pages/pages-contact-save.php" method="post" enctype="multipart/form-data"><label>Email (The form will send to this email</label>
	  <input class="form-control input-lg" type="text" placeholder="your@company.com" name="contact_us_email" value="<?php echo $row['contact_us_email']?>">
	  <br/>
	    <textarea class="textarea" name="contact_us_description" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"> <?php echo $row['contact_us_description']?></textarea>
	  <br/>
	  <br/>
	  <br/>
	  	<div class="box box-danger">
		  <h4 class="box-title">Maps Embed<small> (embed it from google maps)</small>
		  </h4>

	
	    <textarea class="textarea" name="contact_us_map" placeholder="Place your embed here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $row['contact_us_map']?></textarea>
	    </div>
	    <div class="box-footer">
            <button type="submit" class="btn btn-primary"> Save</button>
        </div>
	  </form>

	  	
	</div>
</div>