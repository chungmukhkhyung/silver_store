<!-- box header -->
<div class="box-header with-border">
  <h3 class="box-title">Bank Account
  </h3>
</div>
<!-- /.box-header -->

    <form role="form" action="pages/cart-bank-save.php" method="post" enctype="multipart/form-data">
      <div class="box-body">
      <br/>
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Bank Name</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="bank_name" id="inputEmail3" placeholder="50000">
          </div>
          <div class="col-sm-6"></div>
        </div>
        <br/>
        <br/>
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Account Number</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="acc_num" id="inputEmail3" placeholder="50000">
          </div>
          <div class="col-sm-6"></div>
        </div>
        <br/>
        <br/>
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Account Name</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="acc_name" id="inputEmail3" placeholder="Category Name">
          </div>
        </div>
        <br/>
        <br/>
        <div class="form-group">
          <label for="exampleInputFile">Upload (Recommend size : 300px X 67px)</label>
          <input type="file" id="exampleInputFile" name="bank_img">

          <p class="help-block">Example block-level help text here.</p>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Add</button>
      </div>
    </form>
</div>


<?php include 'koneksi.php';
$bank  = mysqli_query($connect, "SELECT * FROM mcart_bank");
$row        = mysqli_fetch_array($bank);
$no = 1;
?>

<div class="box box-info">
<div class="box-header with-border">
  <h3 class="box-title">View Category
  </h3>
</div>
<!-- /.box-header -->
<!-- table -->
<div class="box-body pad">
  <table class="table table-hover">
    <tbody><tr>
      <th>No</th>
      <th>Bank Name</th>
      <th>Account Name</th>
      <th>Action</th>
    </tr>
    <?php
    foreach ($bank as $row) {
      echo'
      <tr>
        <td>'.$no.'</td>
        <td>'.$row['mcart_bank_name'].'</td>
        <td>'.$row['mcart_bank_acc_name'].'</td>
        <td>
          <a class="btn btn-danger fa fa-trash margin2px" href="index.php?page=cart&act=bank-delete&mcart_bank_id='.$row['mcart_bank_id'].'" ></a>
        </td>
      </tr>
      ';
      $no++;}
      ?>
  </tbody>
  </table>
  <!-- closed table -->
  </div>