<?php include 'koneksi.php';
$query  = mysqli_query($connect, "SELECT * FROM pages_howtoorder WHERE pages_howtoorder_id=1");
$row        = mysqli_fetch_array($query);
?>

<div class="box-header with-border">
  <h3 class="box-title">How to order
  </h3>
</div>
<!-- /.box-header -->
<div class="box-body pad">
  <form action="pages/pages-howtoorder-save.php" method="post" enctype="multipart/form-data">
    <br>
    <textarea class="textarea" name="howtoorder_description" id="tarea" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $row['description'];?></textarea>
    <br>
      <br>
    <div class="box-footer">
      <button type="submit" class="btn btn-primary"> Save</button>
    </div>
  </form>
</div>