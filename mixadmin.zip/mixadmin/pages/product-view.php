<div class="box-header with-border">
  <h3 class="box-title">View Product
  </h3>
</div>
<!-- /.box-header -->
<!-- table -->
<div class="box-body pad">
  <table class="table table-hover">
    <tbody><tr>
      <th>Title</th>
      <th>Category</th>
      <th>Last Modified</th>
      <th>Action</th>
    </tr>
    <tr>
      <td>John Doe John Doe</td>
      <td>sdf fdsa fasdf asd</td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
    <tr>
      <td>Alexander Pierce</td>
      <td>sdf fdsa fasdf asd</td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
    <tr>
      <td>Bob Doe</td>
      <td>sdf fdsa fasdf asd</td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
    <tr>
      <td>Mike Doe</td>
      <td>sdf fdsa fasdf asd</td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-info fa fa-globe margin2px"></a>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
  </tbody>
  </table>
  <!-- closed table -->
</div>