<!-- box header -->
<div class="box-header with-border">
  <h3 class="box-title">Logo
  </h3>
</div>
<!-- /.box-header -->



    <form role="form" action="pages/layout-option-logo-save.php" method="post" enctype="multipart/form-data">
      <div class="box-body">
        <div class="form-group">
          <label>Upload (Recommend size : 300px X 67px)</label>
          <input type="file" name="gambar" id="gambar">

          <p class="help-block">Maximum 1 Mb</p>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Upload</button>
      </div>
    </form>

</div>