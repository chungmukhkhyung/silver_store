<!-- box header -->
<div class="box-header with-border">
  <h3 class="box-title">Bottom Offer
  </h3>
</div>
<!-- /.box-header -->

    <form role="form" action="pages/layout-option-botoffer-save.php" method="post" enctype="multipart/form-data">
      <div class="box-body">
        <div class="form-group">
          <label for="exampleInputFile">Upload (Recommend size : 300px X 67px)</label>
          <input type="file" name="banner">
            <input type="hidden" name="id" value="bottomoffer">

          <p class="help-block">.jpg, .png</p>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Upload</button>
      </div>
    </form>

</div>