	<!-- box header -->
	<div class="box-header with-border">
	  <h3 class="box-title">About Us
	  </h3>
	</div>
	<!-- /.box-header -->
	<div class="box-body pad">
	  <form action="pages/layout-option-footer-save.php" method="post" enctype="multipart/form-data">
	    <textarea class="textarea" name="footer" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
        <input type="hidden" name="id" value="aboutus">
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
	  </form>
	</div>
</div>

<div class="box box-warning">
	<!-- box header -->
	<div class="box-header">
	  <h3 class="box-title">Contact Info
	  </h3>
	</div>
	<!-- /.box-header -->
	<div class="box-body pad">
	  <form action="pages/layout-option-footer-save.php" method="post" enctype="multipart/form-data">
	    <textarea class="textarea" name="footer" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
        <input type="hidden" name="id" value="contactus">
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
	  </form>
	</div>
</div>

<div class="box box-danger">
	<!-- box header -->
	<div class="box-header">
	  <h3 class="box-title">Maps Embed
	  </h3>
	  <small> (embed it from google maps)</small>
	</div>
	<!-- /.box-header -->
	<div class="box-body pad">
	  <form action="pages/layout-option-footer-save.php" method="post" enctype="multipart/form-data">
	    <textarea class="textarea" name="footer" placeholder="Place your embed here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
        <input type="hidden" name="id" value="map">
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
	  </form>
	</div>
</div>

