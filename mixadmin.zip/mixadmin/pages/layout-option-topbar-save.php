<?php
	include "koneksi.php";
	$email           = $_POST['email'];
	$phone           = $_POST['phone'];
	// query SQL untuk insert data
	$query="UPDATE layout_option_topbar  SET email='$email',phone='$phone' WHERE topbar_id=1";
	mysqli_query($connect, $query);
	header("location:../index.php?page=layout-option&act=topbar&notif=success");
?>