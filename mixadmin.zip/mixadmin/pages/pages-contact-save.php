<?php
	include "koneksi.php";
	$email           = $_POST['contact_us_email'];
	$description     = $_POST['contact_us_description'];
	$map     		 = $_POST['contact_us_map'];
	// query SQL untuk insert data
	$query="UPDATE pages_contact_us  SET contact_us_email='$email',contact_us_description='$description',contact_us_map='$map' WHERE contact_us_id=1";
	mysqli_query($connect, $query);
	header("location:../index.php?page=pages&act=contact&notif=success");
?>