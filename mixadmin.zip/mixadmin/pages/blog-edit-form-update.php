<?php
	include "koneksi.php";
	$target_dir 	= "image";
	$blog_id 		= $_POST['id'];
	$blog_title     = $_POST['blog_title'];
	$blog_content   = $_POST['blog_content'];
	$size   	= $_FILES["blog_image"]["size"];
	$blog_image = $_FILES["blog_image"]["name"];
	$date = date('d-M-Y');
	$uploadOk = 1;
	// memeriksa apakah filenya adalah gambar atau bukan
	if(isset($_POST["submit"])) {
		if(empty($_FILES["blog_image"]["tmp_name"])){
			$uploadOk = 1;
		}
		else{
		    $check = getimagesize($_FILES["blog_image"]["tmp_name"]);
		    if($check !== false) {
		        echo "format file gambarnya adalah : " . $check["mime"] . ".";
		        $uploadOk = 1;
		    } else {
		        echo "bukan file gambar";
		        $uploadOk = 0;
		    }
		}
	}
	
	// jika uploadok nilanya 0 maka upload gambar gagal,
	if ($uploadOk == 0) {
	    header("location:../index.php?page=layout-option&act=banner&notif=error");
	//jika tidak maka akan dilakukan proses upload gambar
	} else {
		if(empty($_FILES["blog_image"]["tmp_name"])){
			mysqli_query($connect, "UPDATE blog_add SET blog_title='$blog_title', blog_content='$blog_content', date='$date' WHERE blog_id='$blog_id'");
			header("location:../index.php?page=blog&act=blog-view&notif=success");
		}
		else{
			if($size<=1000000){
				$temp = explode(".", $_FILES["blog_image"]["name"]);//untuk mengambil nama file gambarnya saja tanpa format gambarnya
				$nama_baru = round(microtime(true)) . '.' . end($temp);//fungsi untuk membuat nama acak
			    if (move_uploaded_file($_FILES["blog_image"]["tmp_name"], $target_dir."/" . $nama_baru)) {
					//delete file
					$query=mysqli_query($connect, "SELECT blog_dir_image FROM blog_add WHERE blog_id='$blog_id'");
					$dir=mysqli_fetch_array($query);
					unlink($dir['blog_dir_image']); //delete file now

			    	mysqli_query($connect, "UPDATE blog_add SET blog_title='$blog_title', blog_content='$blog_content', blog_dir_image='$target_dir/$nama_baru',date='$date' WHERE blog_id='$blog_id'");
			        header("location:../index.php?page=blog&act=blog-view&notif=success");

			    } else {
			        header("location:../index.php?page=blog&act=blog-view&notif=error");
			    }
			}
			else{
		        header("location:../index.php?page=blog&act=blog-view&notif=error");
			}    
		}
	}
?>