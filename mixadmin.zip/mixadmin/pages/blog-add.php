<script src="ckeditor/ckeditor.js"></script>
<div class="box-header with-border">
  <h3 class="box-title">Add New Post
  </h3>
</div>
<!-- /.box-header -->
<div class="box-body pad">
  <form action="pages/blog-add-save.php" method="post" enctype="multipart/form-data">
    <input class="form-control input-lg" type="text" name="blog_title" placeholder="Title">
    <br>
    <textarea class="textarea" name="blog_content" id="tarea" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
    <br>
    <br>
    <label>Upload Image</label>
    <input type="file" name="blog_image" id="exampleInputFile">
      <br>
    <div class="box-footer">
      <button type="submit" class="btn btn-primary"> Save</button>
    </div>
  </form>
</div>