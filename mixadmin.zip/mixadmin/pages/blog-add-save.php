<?php
	include "koneksi.php";
	$target_dir = "image";
	$blog_title           = $_POST['blog_title'];
	$blog_content         = $_POST['blog_content'];
	$size   	= $_FILES["blog_image"]["size"];
	$blog_image = $_FILES["blog_image"]["name"];
	$date = date('d-M-Y');
	$uploadOk = 1;
	// memeriksa apakah filenya adalah gambar atau bukan
	if(isset($_POST["submit"])) {
	    $check = getimagesize($_FILES["blog_image"]["tmp_name"]);
	    if($check !== false) {
	        echo "format file gambarnya adalah : " . $check["mime"] . ".";
	        $uploadOk = 1;
	    } else {
	        echo "bukan file gambar";
	        $uploadOk = 0;
	    }
	}
	
	// jika uploadok nilanya 0 maka upload gambar gagal,
	if ($uploadOk == 0) {
	    header("location:../index.php?page=layout-option&act=banner&notif=error");
	//jika tidak maka akan dilakukan proses upload gambar
	} else {
		if($size<=1000000){
			$temp = explode(".", $_FILES["blog_image"]["name"]);//untuk mengambil nama file gambarnya saja tanpa format gambarnya
			$nama_baru = round(microtime(true)) . '.' . end($temp);//fungsi untuk membuat nama acak
		    if (move_uploaded_file($_FILES["blog_image"]["tmp_name"], $target_dir."/" . $nama_baru)) {
		    	mysqli_query($connect, "INSERT INTO blog_add(blog_id,blog_title, blog_content, blog_dir_image,date) VALUES ('','$blog_title','$blog_content','$target_dir/$nama_baru','$date')");
		        header("location:../index.php?page=blog&act=blog-view&notif=success");

		    } else {
		        header("location:../index.php?page=blog&act=blog-view&notif=error");
		    }
		}
		else{
	        header("location:../index.php?page=blog&act=blog-view&notif=error");
		}    
	}
?>