<div class="box-header with-border">
  <h3 class="box-title">Product Categories
  </h3>
</div>
<div class="box-body pad">
  <form>
    <div class="form-group">
      <label for="inputEmail3" class="col-sm-2 control-label">Category Name</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="inputEmail3" placeholder="Name">
      </div>
    </div>
    <br>
    <div class="box-footer col-sm-12">
      <button type="submit" class="btn btn-primary">Add</button>
    </div>
  </form>
</div>

 
<div class="box-header with-border">
  <h3 class="box-title">View Category
  </h3>
</div>
<!-- /.box-header -->
<!-- table -->
<div class="box-body pad">
  <table class="table table-hover">
    <tbody><tr>
      <th>No</th>
      <th>Category Name</th>
      <th>Action</th>
    </tr>
    <?php
    include 'koneksi.php';
    $category = mysqli_query($connect, "SELECT * FROM product_category");
    $no = 1;
    foreach ($category as $row) {
    echo'
    <tr>
      <td>'.$row['product_category_name'].'</td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>';}
    ?>
  </tbody>
  </table>
  <!-- closed table -->
</div>