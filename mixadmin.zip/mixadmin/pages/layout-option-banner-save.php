<?php
	include "koneksi.php";
	$target_dir = "image";
	$size   = $_FILES["banner"]["size"];
	$name   = $_FILES["banner"]["name"];
	$id		= $_POST["id"];
	$uploadOk = 1;
	// memeriksa apakah filenya adalah gambar atau bukan
	if(isset($_POST["submit"])) {
	    $check = getimagesize($_FILES["gambar"]["tmp_name"]);
	    if($check !== false) {
	        echo "format file gambarnya adalah : " . $check["mime"] . ".";
	        $uploadOk = 1;
	    } else {
	        echo "bukan file gambar";
	        $uploadOk = 0;
	    }
	}
	
	// jika uploadok nilanya 0 maka upload gambar gagal,
	if ($uploadOk == 0) {
	    header("location:../index.php?page=layout-option&act=banner&notif=error");
	//jika tidak maka akan dilakukan proses upload gambar
	} else {
		if($size<=1000000){
			$temp = explode(".", $_FILES["banner"]["name"]);//untuk mengambil nama file gambarnya saja tanpa format gambarnya
			$nama_baru = round(microtime(true)) . '.' . end($temp);//fungsi untuk membuat nama acak
		    if (move_uploaded_file($_FILES["banner"]["tmp_name"], $target_dir."/" . $nama_baru)) {
		    	//delete file
				$query=mysqli_query($connect, "SELECT banner_dir FROM layout_option_logo");
				$dir=mysqli_fetch_array($query);
				unlink($dir['banner_dir']); //delete file now

		    	mysqli_query($connect, "UPDATE  layout_option_banner SET banner_name='$name',banner_dir='$target_dir/$nama_baru' WHERE banner_id='$id'");
		        header("location:../index.php?page=layout-option&act=banner&notif=success");

		    } else {
		        header("location:../index.php?page=layout-option&act=banner&notif=error");
		    }
		}
		else{
	        header("location:../index.php?page=layout-option&act=banner&notif=error");
		}    
	}
?>