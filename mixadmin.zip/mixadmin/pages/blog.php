    <section class="content-header">
      <h1>
        Blog
        <small>Tell everyone about your site</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">Editors</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">

          <div class="box box-info">
            <?php 
              if($act=="blog-view")
                include "pages/blog-view.php";
              else if($act=="blog-add")
                include "pages/blog-add.php";
              else if($act=="blog-edit")
                include "pages/blog-edit-form.php";
              else if($act=="blog-delete")
                include "pages/blog-delete.php";

            ;?>

          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>