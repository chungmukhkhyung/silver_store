<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "silver_store";

$connect  = mysqli_connect($hostname, $username, $password, $database); ?>