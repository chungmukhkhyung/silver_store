<?php
	include "koneksi.php";
	$howtoorder_description           = $_POST['howtoorder_description'];
	// query SQL untuk insert data
	$query="UPDATE pages_howtoorder  SET description='$howtoorder_description' WHERE pages_howtoorder_id=1";
	mysqli_query($connect, $query);
	header("location:../index.php?page=pages&act=howtoorder&notif=success");

?>