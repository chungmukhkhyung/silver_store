    <section class="content-header">
      <h1>
        Cart
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">Editors</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">

          <div class="box box-info">
            <?php 
              if($act=="bank")
                include "pages/cart-bank.php";
              else if($act=="customer")
                include "pages/cart-customer.php";
              else if($act=="invoice")
                include "pages/cart-invoice.php";
              else if($act=="bank-delete")
                include "pages/cart-bank-delete.php";

            ;?>

          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>