<?php
	ini_set('display_errors', 1);
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
	include "koneksi.php";
	$target_dir = "image";
	$product_title           = $_POST['product_title'];
	$product_description         = $_POST['product_description'];
	$product_price           = $_POST['product_price'];
	$product_category         = $_POST['product_category'];
	$product_stock         = $_POST['product_stock'];
	$size1   	= $_FILES["product_image1"]["size"];
	$product_image1 = $_FILES["product_image1"]["name"];
	$size2   	= $_FILES["product_image2"]["size"];
	$product_image2 = $_FILES["product_image2"]["name"];
	$size3   	= $_FILES["product_image3"]["size"];
	$product_image3 = $_FILES["product_image3"]["name"];
	$date = date('d-M-Y');
	$uploadOk1 = 1;
	$uploadOk2 = 1;
	$uploadOk3 = 1;
	if(isset($_POST["submit"])) {
	    $check1 = getimagesize($_FILES["product_image1"]["tmp_name"]);
	    if($check1 !== false) {
	        echo "format file gambarnya adalah : " . $check1["mime"] . ".";
	        $uploadOk1 = 1;
	    } else {
	        echo "bukan file gambar";
	        $uploadOk1 = 0;
	    }
	}
	if(isset($_POST["submit"])) {
	    $check2 = getimagesize($_FILES["product_image2"]["tmp_name"]);
	    if($check2 !== false) {
	        echo "format file gambarnya adalah : " . $check2["mime"] . ".";
	        $uploadOk2 = 1;
	    } else {
	        echo "bukan file gambar";
	        $uploadOk2 = 0;
	    }
	}
	if(isset($_POST["submit"])) {
	    $check3 = getimagesize($_FILES["product_image3"]["tmp_name"]);
	    if($check3 !== false) {
	        echo "format file gambarnya adalah : " . $check3["mime"] . ".";
	        $uploadOk3 = 1;
	    } else {
	        echo "bukan file gambar";
	        $uploadOk3 = 0;
	    }
	}
	
	// jika uploadok nilanya 0 maka upload gambar gagal,
	if ($uploadOk1 == 0 ) {
	    header("location:../index.php?page=product&act=view&notif=error");
	}
	else if ($uploadOk2 == 0 ) {
	    header("location:../index.php?page=product&act=view&notif=error");
	}
	else if ($uploadOk3 == 0 ) {
	    header("location:../index.php?page=product&act=view&notif=error");
	} else {
		if($size1<=1000000 && $size2<=1000000 && $size3<=1000000){
			$temp1 = explode(".", $_FILES["product_image1"]["name"]);//untuk mengambil nama file gambarnya saja tanpa format gambarnya
			$temp2 = explode(".", $_FILES["product_image2"]["name"]);//untuk mengambil nama file gambarnya saja tanpa format gambarnya
			$temp3 = explode(".", $_FILES["product_image3"]["name"]);//untuk mengambil nama file gambarnya saja tanpa format gambarnya
			$nama_baru1 = round(microtime(true)) . '1.' . end($temp1);//fungsi untuk membuat nama acak
			$nama_baru2 = round(microtime(true)) . '2.' . end($temp2);//fungsi untuk membuat nama acak
			$nama_baru3 = round(microtime(true)) . '3.' . end($temp3);//fungsi untuk membuat nama acak
		    if (move_uploaded_file($_FILES["product_image1"]["tmp_name"], $target_dir."/" . $nama_baru1) &&
		    	move_uploaded_file($_FILES["product_image2"]["tmp_name"], $target_dir."/" . $nama_baru2)&&
		    	move_uploaded_file($_FILES["product_image3"]["tmp_name"], $target_dir."/" . $nama_baru3)
		    	) {
		    	mysqli_query($connect, "INSERT INTO product(product_id, product_name, product_description, product_price, product_date, product_image1, product_image2, product_image3, product_category_id, product_stock)
		    		VALUES ('','$product_title','$product_description','$product_price','$date','$target_dir/$nama_baru1','$target_dir/$nama_baru2','$target_dir/$nama_baru3','$product_category','$product_stock')");
		        header("location:../index.php?page=product&act=view&notif=success");


		    } else {
		        header("location:../index.php?page=product&act=view&notif=error");
		    }
		}
		else{
	        header("location:../index.php?page=product&act=view&notif=error");
		}    
	}

?>