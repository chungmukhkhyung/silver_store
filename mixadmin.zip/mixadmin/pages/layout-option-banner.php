  <!-- box header -->
  <div class="box-header with-border">
    <h3 class="box-title">Main Banner
    </h3>
  </div>
  <!-- /.box-header -->

      <form role="form" action="pages/layout-option-banner-save.php" method="post" enctype="multipart/form-data">
        <div class="box-body">
          <div class="form-group">
            <label for="exampleInputFile">Upload (Recommend size : 1280px × 853px)</label>
            <input type="file" name="banner">
            <input type="hidden" name="id" value="mainbanner">

            <p class="help-block">.jpg, .png (Maximum 1 Mb)</p>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
</div>

<!-- box -->
<div class="box box-danger">
<div class="box-header">
    <h3 class="box-title">Left Medium Banner
    </h3>
  </div>
  <!-- /.box-header -->

      <form role="form" action="pages/layout-option-banner-save.php" method="post" enctype="multipart/form-data">
        <div class="box-body">
          <div class="form-group">
            <label for="exampleInputFile">Upload (Recommend size : 388px × 426px)</label>
            <input type="file" name="banner" id="exampleInputFile">

            <p class="help-block">.jpg, .png (Maximum 1 Mb)</p>
            <input type="hidden" name="id" value="leftmediumbanner">
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
</div>
<!-- close box -->

<!-- box -->
<div class="box box-success">
<div class="box-header">
    <h3 class="box-title">Middle Top Banner
    </h3>
  </div>
  <!-- /.box-header -->

      <form role="form" action="pages/layout-option-banner-save.php" method="post" enctype="multipart/form-data">
        <div class="box-body">
          <div class="form-group">
            <label for="exampleInputFile">Upload (Recommend size : 640px × 345px)</label>
            <input type="file" name="banner">
            <input type="hidden" name="id" value="middletopbanner">

            <p class="help-block">.jpg, .png (Maximum 1 Mb)</p>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
</div>
<!-- close box -->

<!-- box -->
<div class="box box-warning">
<div class="box-header">
    <h3 class="box-title">Middle Bottom Banner
    </h3>
  </div>
  <!-- /.box-header -->

      <form role="form" action="pages/layout-option-banner-save.php" method="post" enctype="multipart/form-data">
        <div class="box-body">
          <div class="form-group">
            <label for="exampleInputFile">Upload (Recommend size : 640px × 345px)</label>
            <input type="file" name="banner">
            <input type="hidden" name="id" value="middlebottombanner">
            <p class="help-block">.jpg, .png (Maximum 1 Mb)</p>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
</div>
<!-- close box -->

<!-- box -->
<div class="box box-primary">
<div class="box-header">
    <h3 class="box-title">Right Medium Banner
    </h3>
  </div>
  <!-- /.box-header -->

      <form role="form" action="pages/layout-option-banner-save.php" method="post" enctype="multipart/form-data">
        <div class="box-body">
          <div class="form-group">
            <label for="exampleInputFile">Upload (Recommend size : 427px × 491px)</label>
            <input type="file" name="banner">
            <input type="hidden" name="id" value="rightmediumbanner">

            <p class="help-block">.jpg, .png (Maximum 1 Mb)</p>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
</div>
<!-- close box -->