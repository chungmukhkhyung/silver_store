<?php
	include "koneksi.php";
	$facebook           = $_POST['facebook'];
	$twitter            = $_POST['twitter'];
	$instagram           = $_POST['instagram'];
	// query SQL untuk insert data
	$query="UPDATE layout_option_sosmed  SET facebook='$facebook',twitter='$twitter',instagram='$instagram' WHERE sosmed_id=1";
	mysqli_query($connect, $query);
	header("location:../index.php?page=layout-option&act=sosmed&notif=success");

?>