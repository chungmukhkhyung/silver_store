<!--box header -->
<div class="box-header with-border">
  <h3 class="box-title">View Invoice
  </h3>
</div>
<!-- /.box-header -->
<!-- table -->
<div class="box-body pad">
  <table class="table table-hover">
    <tbody><tr>
      <th>Invoice#</th>
      <th>Customer Name</th>
      <th>Date</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
    <tr>
      <td>1</td>
      <td>Mike Doe</td>
      <td>11-7-2014</td>
      <td><span class="label label-success">Payed</span></td></td>
      <td>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
    <tr>
      <td>1</td>
      <td>Mike Doe</td>
      <td>11-7-2014</td>
      <td><span class="label label-danger">Un-payed</span></td></td>
      <td>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
  </tbody>
  </table>
  <!-- closed table -->
  </div>