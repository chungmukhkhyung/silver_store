<?php include 'koneksi.php';
$blog_id = isset($_GET['blog_id']) ? $_GET['blog_id'] : '';
$blog  = mysqli_query($connect, "SELECT * FROM blog_add WHERE blog_id='$blog_id'");
$row        = mysqli_fetch_array($blog);
?>
<script src="ckeditor/ckeditor.js"></script>
<div class="box-header with-border">
  <h3 class="box-title">Add New Post
  </h3>
</div>
<!-- /.box-header -->
<div class="box-body pad">
  <form action="pages/blog-edit-form-update.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $blog_id;?>">
    <input class="form-control input-lg" type="text" name="blog_title" placeholder="Title" value="<?php echo $row['blog_title'];?>">
    <br>
    <textarea class="textarea" name="blog_content" id="tarea" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" ><?php echo $row['blog_content'];?></textarea>
    <br>
    <br>
    <img width="100px" height="100px" src="pages/<?php echo $row['blog_dir_image'];?>">
    <br>
    <br>
    <label>Upload Image</label>
    <input type="file" name="blog_image" id="exampleInputFile">
    <div class="box-footer">
      <button type="submit" class="btn btn-primary"> Save</button>
    </div>
  </form>
</div>