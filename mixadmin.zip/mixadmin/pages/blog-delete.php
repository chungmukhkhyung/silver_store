<?php
include 'koneksi.php';
// menyimpan data id kedalam variabel
$blog_id  = $_GET['blog_id'];

//delete file
$query=mysqli_query($connect, "SELECT blog_dir_image FROM blog_add where blog_id='$blog_id'");
$dir=mysqli_fetch_array($query);
unlink(__DIR__.'/'.$dir['blog_dir_image']); //delete file now

$query="DELETE from blog_add where blog_id='$blog_id'";
mysqli_query($connect, $query);
// mengalihkan ke halaman index.php
header("location:index.php?page=blog&act=blog-view&notif=success");

?>