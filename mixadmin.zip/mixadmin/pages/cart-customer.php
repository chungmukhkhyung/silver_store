<!-- box header -->
<div class="box-header with-border">
  <h3 class="box-title">Bank Account
  </h3>
</div>
<!-- /.box-header -->

    <form role="form">
      <div class="box-body">
      <br/>
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="inputEmail3" placeholder="50000">
          </div>
          <div class="col-sm-6"></div>
        </div>
        <br/>
        <br/>
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="inputEmail3" placeholder="50000">
          </div>
          <div class="col-sm-6"></div>
        </div>
        <br/>
        <br/>
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Phone</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="inputEmail3" placeholder="Category Name">
          </div>
        </div>
        <br/>
        <br/>
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="inputEmail3" placeholder="Category Name">
          </div>
        </div>
        <br/>
        <br/>
         <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Register Date</label>
          <div class="col-sm-4">
            <input type="date" class="form-control" id="inputEmail3" placeholder="Category Name">
          </div>
        </div>
        <br/>
        <br/>
        <div class="form-group col-sm-12">
          <label for="exampleInputFile">Upload (Recommend size : 300px X 67px)</label>
          <input type="file" id="exampleInputFile">

          <p class="help-block">Example block-level help text here.</p>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Add</button>
      </div>
    </form>
</div>

<!--box header -->
<div class="box box-info">
<div class="box-header with-border">
  <h3 class="box-title">View Customer
  </h3>
</div>
<!-- /.box-header -->
<!-- table -->
<div class="box-body pad">
  <table class="table table-hover">
    <tbody><tr>
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Register Date</th>
      <th>Action</th>
    </tr>
    <tr>
      <td>1</td>
      <td>Mike Doe</td>
      <td>Mikedo@gmail.com</td>
      <td>08123456789</td>
      <td>11-7-2014</td>
      <td>
        <a class="btn btn-warning fa fa-edit margin2px"></a>
        <a class="btn btn-danger fa fa-trash margin2px"></a>
      </td>
    </tr>
  </tbody>
  </table>
  <!-- closed table -->
  </div>