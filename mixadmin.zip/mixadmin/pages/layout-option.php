    <section class="content-header">
      <h1>
        Layout Option
        <small>Manage website layout</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">Editors</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">

          <div class="box box-info">
            <?php 
              if($act=="logo")
                include "pages/layout-option-logo.php";
              else if($act=="topbar")
                include "pages/layout-option-topbar.php";
              else if($act=="sosmed")
                include "pages/layout-option-sosmed.php";
              else if($act=="banner")
                include "pages/layout-option-banner.php";
              else if($act=="botOffer")
                include "pages/layout-option-botOffer.php";
              else if($act=="footer")
                include "pages/layout-option-footer.php";

            ;?>

          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>