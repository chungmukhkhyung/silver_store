<div class="box-header with-border">
  <h3 class="box-title">View Post
  </h3>
</div>
<!-- /.box-header -->
<!-- table -->
<div class="box-body pad">
  <table class="table table-hover">
    <tbody><tr>
      <th>No</th>
      <th>Title</th>
      <th>Last Modified</th>
      <th>Action</th>
    </tr>
    <?php
    include 'koneksi.php';
    $blogs = mysqli_query($connect, "SELECT * FROM blog_add");
    $no = 1;
    foreach ($blogs as $row) {
      echo'
      <tr>
        <td>'.$no.'</td>
        <td>'.$row['blog_title'].'</td>
        <td>'.$row['date'].'</td>
        <td>
          <a class="btn btn-info fa fa-globe margin2px"></a>
          <a class="btn btn-warning fa fa-edit margin2px" href="index.php?page=blog&act=blog-edit&blog_id='.$row['blog_id'].'"></a>
          <a class="btn btn-danger fa fa-trash margin2px" href="index.php?page=blog&act=blog-delete&blog_id='.$row['blog_id'].'" ></a>
        </td>
      </tr>
      ';
      //onclick=\"return confirm('Are you sure?')\"
      $no++;}
    ?>
  </table>
  <!-- closed table -->
</div>